import React from "react";

function Note ()  {
 return (
    <div className= "note">
      <h1>
        Javascript and React.js </h1>
        <p>
          This was an amazing bootcamp taken by Shaurya sinha.We covered everything from scratch including 
          Javascript and React.js, HTML.
          </p> 
          </div>
    );
  }

export default Note; 
